# उत्सव कैलेंडर – APK बनाने के निर्देश (मोबाइल से)

यह Android Studio का Kotlin/Jetpack Compose प्रोजेक्ट है। इस ZIP में APK बनाने के लिए GitHub Actions workflow जोड़ा गया है। APK इस वातावरण में अभी compile/test नहीं हुई है।

## फोन से APK बनाने का तरीका

1. ZIP को extract करें।
2. GitHub पर sign in करके नया **Private repository** बनाएं।
3. Extract किए गए project की सभी files/folders repository में upload करें। `.github/workflows/build-apk.yml` भी upload होना चाहिए।
4. `main` branch पर upload/push पूरा होने पर GitHub में **Actions** tab खोलें।
5. **Build Android APK** workflow चुनें। जरूरत हो तो **Run workflow** दबाएं।
6. Build सफल होने पर workflow run के नीचे **Artifacts** में `UtsavCalendar-debug-apk` मिलेगा। उसे download करके ZIP खोलें; उसमें `app-debug.apk` होगा।
7. APK खोलकर Android के prompt पर इस source से app install करने की अनुमति दें।

## ध्यान दें

- यह **debug APK** होगी، Play Store release APK نہیں۔
- यह build अभी चलाकर verify नहीं की गई है; dependency या SDK error आए तो Actions के build log से उसे ठीक करना होगा।
- App में Firebase Authentication/Firestore उपयोग होता है। Login और cloud data features तभी ठीक से चलेंगे जब Firebase project में Android app का package name `com.aistudio.utsavcalendar.vmqtrp` configure हो और Firebase की सही security rules हों।
- Firebase config file `app/google-services.json` पहले से project में है। इसे सार्वजनिक repository में डालने के बजाय Private repository रखें।
- `.env` में Gemini API key केवल तभी डालें जब app सच में Gemini API call करती हो; key को source code या public repo में न डालें।
