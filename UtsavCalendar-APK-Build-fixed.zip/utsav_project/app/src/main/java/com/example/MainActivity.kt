package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.Cake
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Celebration
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.auth.authStateFlow
import com.example.auth.signOut
import com.example.data.model.IndianFestival
import com.example.data.model.PersonalEvent
import com.example.data.model.TodoItem
import com.example.data.repository.CalendarRepository
import com.example.ui.components.AddEditEventSheet
import com.example.ui.components.AddEditTodoSheet
import com.example.ui.components.FestivalDetailBottomSheet
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.EventsScreen
import com.example.ui.screens.FestivalsScreen
import com.example.ui.screens.TodosScreen
import com.example.ui.theme.UtsavCalendarTheme
import com.example.ui.viewmodel.CalendarViewModel
import com.example.ui.viewmodel.UiState
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

enum class CalendarTab(
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    CALENDAR("कैलेंडर", Icons.Filled.CalendarMonth, Icons.Outlined.CalendarMonth, "nav_tab_calendar"),
    FESTIVALS("त्योहार", Icons.Filled.Celebration, Icons.Outlined.Celebration, "nav_tab_festivals"),
    TODOS("टू-डू", Icons.Filled.CheckCircle, Icons.Outlined.CheckCircle, "nav_tab_todos"),
    EVENTS("बर्थडे/पार्टी", Icons.Filled.Cake, Icons.Outlined.Cake, "nav_tab_events")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            UtsavCalendarTheme {
                AppNavigation()
            }
        }
    }
}

@Composable
fun AppNavigation() {
    val auth = Firebase.auth
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    if (user == null) {
        AuthScreen(onAuthSuccess = {})
    } else {
        key(user.uid) {
            MainFeatureScreen(
                currentUserId = user.uid,
                userName = user.displayName,
                userEmail = user.email
            )
        }
    }
}

private data class TodoSheetRequest(
    val existingTodo: TodoItem? = null,
    val defaultDateKey: String,
    val prefillTitle: String = "",
    val prefillCategory: String = "general"
)

private data class EventSheetRequest(
    val existingEvent: PersonalEvent? = null,
    val defaultDateKey: String,
    val defaultEventType: String = "birthday"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainFeatureScreen(
    currentUserId: String,
    userName: String?,
    userEmail: String?
) {
    val viewModel: CalendarViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                CalendarViewModel(
                    repository = CalendarRepository(app),
                    currentUserId = currentUserId
                )
            }
        }
    )

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val displayedYear by viewModel.displayedYear.collectAsStateWithLifecycle()
    val displayedMonth by viewModel.displayedMonth.collectAsStateWithLifecycle()
    val selectedDate by viewModel.selectedDate.collectAsStateWithLifecycle()
    val selectedFestivalYear by viewModel.selectedFestivalYear.collectAsStateWithLifecycle()
    val festivalCategoryFilter by viewModel.festivalCategoryFilter.collectAsStateWithLifecycle()
    val festivalSearchQuery by viewModel.festivalSearchQuery.collectAsStateWithLifecycle()
    val todoFilter by viewModel.todoFilter.collectAsStateWithLifecycle()
    val eventTypeFilter by viewModel.eventTypeFilter.collectAsStateWithLifecycle()
    val todosState by viewModel.todosState.collectAsStateWithLifecycle()
    val eventsState by viewModel.eventsState.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()

    var currentTab by remember { mutableStateOf(CalendarTab.CALENDAR) }
    var selectedFestivalForDetail by remember { mutableStateOf<IndianFestival?>(null) }
    var todoSheetRequest by remember { mutableStateOf<TodoSheetRequest?>(null) }
    var eventSheetRequest by remember { mutableStateOf<EventSheetRequest?>(null) }
    var showAccountMenu by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMessage) {
        val msg = snackbarMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    if (currentTab != CalendarTab.CALENDAR) {
        BackHandler {
            currentTab = CalendarTab.CALENDAR
        }
    }

    val loadedTodos = (todosState as? UiState.Success)?.data ?: emptyList()
    val loadedEvents = (eventsState as? UiState.Success)?.data ?: emptyList()
    val upcomingFestival = remember(selectedDate) { viewModel.getUpcomingFestival() }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isExpandedWidth = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = stringResource(id = R.string.app_name),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = currentTab.label,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background
                    ),
                    actions = {
                        Box {
                            IconButton(
                                onClick = { showAccountMenu = true },
                                modifier = Modifier.testTag("account_menu_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AccountCircle,
                                    contentDescription = "खाता विकल्प",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            DropdownMenu(
                                expanded = showAccountMenu,
                                onDismissRequest = { showAccountMenu = false }
                            ) {
                                if (!userName.isNullOrBlank() || !userEmail.isNullOrBlank()) {
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                if (!userName.isNullOrBlank()) {
                                                    Text(userName, fontWeight = FontWeight.Bold)
                                                }
                                                if (!userEmail.isNullOrBlank()) {
                                                    Text(
                                                        userEmail,
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                        },
                                        onClick = {}
                                    )
                                }
                                DropdownMenuItem(
                                    text = { Text(stringResource(id = R.string.sign_out)) },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.Logout,
                                            contentDescription = null
                                        )
                                    },
                                    onClick = {
                                        showAccountMenu = false
                                        signOut(credentialManager, coroutineScope)
                                    },
                                    modifier = Modifier.testTag("sign_out_menu_item")
                                )
                            }
                        }
                    }
                )
            },
            bottomBar = {
                if (!isExpandedWidth) {
                    NavigationBar(
                        windowInsets = WindowInsets.navigationBars,
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        CalendarTab.entries.forEach { tab ->
                            val selected = currentTab == tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = { currentTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label, maxLines = 1) },
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }
            },
            floatingActionButton = {
                val (fabText, fabAction) = when (currentTab) {
                    CalendarTab.CALENDAR, CalendarTab.TODOS -> "टू-डू जोड़ें" to {
                        todoSheetRequest = TodoSheetRequest(
                            defaultDateKey = selectedDate.toDateKey()
                        )
                    }
                    CalendarTab.FESTIVALS -> "मेरा त्योहार" to {
                        eventSheetRequest = EventSheetRequest(
                            defaultDateKey = selectedDate.toDateKey(),
                            defaultEventType = "festival"
                        )
                    }
                    CalendarTab.EVENTS -> "अवसर जोड़ें" to {
                        eventSheetRequest = EventSheetRequest(
                            defaultDateKey = selectedDate.toDateKey(),
                            defaultEventType = "birthday"
                        )
                    }
                }
                ExtendedFloatingActionButton(
                    onClick = fabAction,
                    icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                    text = { Text(fabText) },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("main_fab")
                )
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isExpandedWidth) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        CalendarTab.entries.forEach { tab ->
                            val selected = currentTab == tab
                            NavigationRailItem(
                                selected = selected,
                                onClick = { currentTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label, maxLines = 1) },
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    when (currentTab) {
                        CalendarTab.CALENDAR -> CalendarScreen(
                            displayedYear = displayedYear,
                            displayedMonth = displayedMonth,
                            selectedDate = selectedDate,
                            todos = loadedTodos,
                            events = loadedEvents,
                            onPreviousMonth = viewModel::previousMonth,
                            onNextMonth = viewModel::nextMonth,
                            onJumpToday = viewModel::jumpToToday,
                            onJumpToYearMonth = viewModel::jumpToYearMonth,
                            onSelectDate = viewModel::selectDate,
                            onOpenFestival = { selectedFestivalForDetail = it },
                            onAddTodoForDate = { dateKey ->
                                todoSheetRequest = TodoSheetRequest(defaultDateKey = dateKey)
                            },
                            onEditTodo = { todo ->
                                todoSheetRequest = TodoSheetRequest(
                                    existingTodo = todo,
                                    defaultDateKey = todo.dateKey
                                )
                            },
                            onToggleTodo = viewModel::toggleTodoCompleted,
                            onDeleteTodo = viewModel::deleteTodo,
                            onAddEventForDate = { dateKey ->
                                eventSheetRequest = EventSheetRequest(
                                    defaultDateKey = dateKey,
                                    defaultEventType = "birthday"
                                )
                            },
                            onEditEvent = { ev ->
                                eventSheetRequest = EventSheetRequest(
                                    existingEvent = ev,
                                    defaultDateKey = ev.dateKey,
                                    defaultEventType = ev.eventType
                                )
                            },
                            onDeleteEvent = viewModel::deletePersonalEvent
                        )

                        CalendarTab.FESTIVALS -> FestivalsScreen(
                            selectedYear = selectedFestivalYear,
                            selectedCategory = festivalCategoryFilter,
                            searchQuery = festivalSearchQuery,
                            upcomingFestival = upcomingFestival,
                            customFestivals = loadedEvents.filter { it.eventType == "festival" },
                            onSelectYear = viewModel::setFestivalYear,
                            onSelectCategory = viewModel::setFestivalCategory,
                            onSearchQueryChange = viewModel::setFestivalSearchQuery,
                            onOpenFestival = { selectedFestivalForDetail = it },
                            onEditCustomFestival = { ev ->
                                eventSheetRequest = EventSheetRequest(
                                    existingEvent = ev,
                                    defaultDateKey = ev.dateKey,
                                    defaultEventType = "festival"
                                )
                            },
                            onDeleteCustomFestival = viewModel::deletePersonalEvent
                        )

                        CalendarTab.TODOS -> TodosScreen(
                            todosState = todosState,
                            selectedFilter = todoFilter,
                            onSelectFilter = viewModel::setTodoFilter,
                            onToggleTodo = viewModel::toggleTodoCompleted,
                            onEditTodo = { todo ->
                                todoSheetRequest = TodoSheetRequest(
                                    existingTodo = todo,
                                    defaultDateKey = todo.dateKey
                                )
                            },
                            onDeleteTodo = viewModel::deleteTodo
                        )

                        CalendarTab.EVENTS -> EventsScreen(
                            eventsState = eventsState,
                            selectedTypeFilter = eventTypeFilter,
                            onSelectTypeFilter = viewModel::setEventTypeFilter,
                            onEditEvent = { ev ->
                                eventSheetRequest = EventSheetRequest(
                                    existingEvent = ev,
                                    defaultDateKey = ev.dateKey,
                                    defaultEventType = ev.eventType
                                )
                            },
                            onDeleteEvent = viewModel::deletePersonalEvent
                        )
                    }
                }
            }
        }
    }

    selectedFestivalForDetail?.let { festival ->
        FestivalDetailBottomSheet(
            festival = festival,
            onDismiss = { selectedFestivalForDetail = null },
            onAddPrepTodo = { fest ->
                selectedFestivalForDetail = null
                todoSheetRequest = TodoSheetRequest(
                    defaultDateKey = fest.dateKey,
                    prefillTitle = "${fest.nameHi} की तैयारी",
                    prefillCategory = "festival_prep"
                )
            }
        )
    }

    todoSheetRequest?.let { req ->
        AddEditTodoSheet(
            initialTodo = req.existingTodo,
            defaultDateKey = req.defaultDateKey,
            prefillTitle = req.prefillTitle,
            prefillCategory = req.prefillCategory,
            onDismiss = { todoSheetRequest = null },
            onSave = { title, notes, dateKey, priority, category ->
                viewModel.saveTodo(
                    existingTodo = req.existingTodo,
                    title = title,
                    notes = notes,
                    dateKey = dateKey,
                    priority = priority,
                    category = category
                )
                todoSheetRequest = null
            }
        )
    }

    eventSheetRequest?.let { req ->
        AddEditEventSheet(
            initialEvent = req.existingEvent,
            defaultDateKey = req.defaultDateKey,
            defaultEventType = req.defaultEventType,
            onDismiss = { eventSheetRequest = null },
            onSave = { title, eventType, dateKey, repeatYearly, timeLabel, location, notes ->
                viewModel.savePersonalEvent(
                    existingEvent = req.existingEvent,
                    title = title,
                    eventType = eventType,
                    dateKey = dateKey,
                    repeatYearly = repeatYearly,
                    timeLabel = timeLabel,
                    location = location,
                    notes = notes
                )
                eventSheetRequest = null
            }
        )
    }
}
