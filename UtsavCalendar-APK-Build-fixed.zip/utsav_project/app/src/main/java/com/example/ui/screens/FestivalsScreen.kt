package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.festivals.IndianFestivalsCatalog
import com.example.data.model.FestivalCategory
import com.example.data.model.IndianFestival
import com.example.data.model.PersonalEvent
import com.example.ui.components.FestivalCard
import com.example.ui.components.PersonalEventCard
import com.example.util.CalendarDate

@Composable
fun FestivalsScreen(
    selectedYear: Int,
    selectedCategory: FestivalCategory?,
    searchQuery: String,
    upcomingFestival: IndianFestival?,
    customFestivals: List<PersonalEvent>,
    onSelectYear: (Int) -> Unit,
    onSelectCategory: (FestivalCategory?) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onOpenFestival: (IndianFestival) -> Unit,
    onEditCustomFestival: (PersonalEvent) -> Unit,
    onDeleteCustomFestival: (String) -> Unit
) {
    var showYearPickerDialog by remember { mutableStateOf(false) }
    val supportedYears = IndianFestivalsCatalog.SUPPORTED_YEARS
    val yearListState = rememberLazyListState()

    LaunchedEffect(selectedYear) {
        val index = supportedYears.indexOf(selectedYear)
        if (index >= 0) {
            yearListState.animateScrollToItem((index - 1).coerceAtLeast(0))
        }
    }

    val filteredFestivals = remember(selectedYear, selectedCategory, searchQuery) {
        val yearPrefix = "$selectedYear-"
        val q = searchQuery.trim().lowercase()
        IndianFestivalsCatalog.allFestivals.filter { fest ->
            val matchesYear = if (q.isNotEmpty()) true else fest.dateKey.startsWith(yearPrefix)
            val matchesCat = selectedCategory == null || fest.category == selectedCategory
            val matchesQuery = q.isEmpty() ||
                fest.nameHi.lowercase().contains(q) ||
                fest.nameEn.lowercase().contains(q) ||
                fest.region.lowercase().contains(q) ||
                fest.lunarTithi.lowercase().contains(q) ||
                fest.shortSummaryHi.lowercase().contains(q) ||
                fest.dateKey.contains(q)
            matchesYear && matchesCat && matchesQuery
        }
    }

    if (showYearPickerDialog) {
        AlertDialog(
            onDismissRequest = { showYearPickerDialog = false },
            title = {
                Text(
                    text = "वर्ष चुनें (2000 – 2035)",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.heightIn(max = 320.dp)
                ) {
                    items(supportedYears) { year ->
                        val isSelected = year == selectedYear
                        Surface(
                            onClick = {
                                onSelectYear(year)
                                showYearPickerDialog = false
                            },
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
                            }
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.padding(vertical = 10.dp)
                            ) {
                                Text(
                                    text = "$year",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (isSelected) {
                                        MaterialTheme.colorScheme.onPrimary
                                    } else {
                                        MaterialTheme.colorScheme.onSurface
                                    },
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showYearPickerDialog = false }) {
                    Text("बंद करें")
                }
            }
        )
    }

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Festive Hero Banner Card
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(176.dp)
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        Image(
                            painter = painterResource(id = R.drawable.img_festival_banner),
                            contentDescription = "भारतीय त्योहार पंचांग",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            Color(0xD93B1204),
                                            Color(0x993B1204),
                                            Color(0x403B1204)
                                        )
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(18.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFFFFD166)
                                ) {
                                    Text(
                                        text = "संपूर्ण भारत पंचांग (2000 – 2035)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF421200),
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "भारत के सभी प्रमुख त्योहार",
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (upcomingFestival != null) {
                                val upDate = CalendarDate.parse(upcomingFestival.dateKey)
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color.Black.copy(alpha = 0.45f),
                                    onClick = { onOpenFestival(upcomingFestival) }
                                ) {
                                    Text(
                                        text = "आगामी पर्व: ${upcomingFestival.nameHi} • ${upDate?.formatShort() ?: upcomingFestival.dateKey}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = Color(0xFFFFE6A7),
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Search bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = { Text("त्योहार, वर्ष या राज्य खोजें (जैसे: दिवाली, 2030, छठ)...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchQueryChange("") }) {
                                Icon(Icons.Filled.Close, contentDescription = "खोज साफ़ करें")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("festival_search_input")
                )
            }

            // Year selector (2000-2035) + Category chips
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showYearPickerDialog = true },
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier
                                .height(40.dp)
                                .testTag("festival_year_picker_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CalendarMonth,
                                contentDescription = "सभी वर्ष चुनें",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("वर्ष: $selectedYear", style = MaterialTheme.typography.labelLarge)
                        }

                        LazyRow(
                            state = yearListState,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            items(supportedYears) { year ->
                                FilterChip(
                                    selected = selectedYear == year,
                                    onClick = { onSelectYear(year) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                    ),
                                    label = { Text("$year") }
                                )
                            }
                        }
                    }

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            FilterChip(
                                selected = selectedCategory == null,
                                onClick = { onSelectCategory(null) },
                                label = { Text("सभी त्योहार") }
                            )
                        }
                        items(FestivalCategory.entries) { category ->
                            FilterChip(
                                selected = selectedCategory == category,
                                onClick = {
                                    onSelectCategory(if (selectedCategory == category) null else category)
                                },
                                label = { Text(category.labelHi) }
                            )
                        }
                    }
                }
            }

            if (customFestivals.isNotEmpty() && selectedCategory == null && searchQuery.isBlank()) {
                item {
                    Text(
                        text = "आपके द्वारा जोड़े गए कस्टम त्योहार",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.tertiary,
                        fontWeight = FontWeight.Bold
                    )
                }
                items(customFestivals, key = { "custom_${it.id}" }) { custom ->
                    PersonalEventCard(
                        event = custom,
                        onEdit = { onEditCustomFestival(custom) },
                        onDelete = { onDeleteCustomFestival(custom.id) }
                    )
                }
            }

            item {
                val countText = if (searchQuery.trim().isNotEmpty()) {
                    "2000–2035 के सभी वर्षों में ${filteredFestivals.size} त्योहार मिले"
                } else {
                    "वर्ष $selectedYear में ${filteredFestivals.size} त्योहार व प्रमुख दिवस उपलब्ध"
                }
                Text(
                    text = countText,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (filteredFestivals.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Filled.SearchOff,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "कोई मिलता-जुलता त्योहार नहीं मिला",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "कृपया खोज शब्द बदलें या सभी श्रेणियाँ चुनें",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                items(filteredFestivals, key = { it.id }) { festival ->
                    FestivalCard(
                        festival = festival,
                        onClick = { onOpenFestival(festival) }
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(72.dp)) }
        }
    }
}
