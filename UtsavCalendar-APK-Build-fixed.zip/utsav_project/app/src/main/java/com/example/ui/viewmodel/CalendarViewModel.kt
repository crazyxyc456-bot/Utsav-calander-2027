package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.festivals.IndianFestivalsCatalog
import com.example.data.model.FestivalCategory
import com.example.data.model.IndianFestival
import com.example.data.model.PersonalEvent
import com.example.data.model.TodoItem
import com.example.data.repository.CalendarRepository
import com.example.util.CalendarDate
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

enum class TodoFilter(val labelHi: String) {
    ALL("सभी"),
    PENDING("बाकी"),
    COMPLETED("पूर्ण")
}

class CalendarViewModel(
    private val repository: CalendarRepository,
    private val currentUserId: String
) : ViewModel() {

    private val todayDate = CalendarDate.today()

    private val _displayedYear = MutableStateFlow(todayDate.year)
    val displayedYear: StateFlow<Int> = _displayedYear.asStateFlow()

    private val _displayedMonth = MutableStateFlow(todayDate.month)
    val displayedMonth: StateFlow<Int> = _displayedMonth.asStateFlow()

    private val _selectedDate = MutableStateFlow(todayDate)
    val selectedDate: StateFlow<CalendarDate> = _selectedDate.asStateFlow()

    private val _selectedFestivalYear = MutableStateFlow(
        todayDate.year.coerceIn(IndianFestivalsCatalog.MIN_YEAR, IndianFestivalsCatalog.MAX_YEAR)
    )
    val selectedFestivalYear: StateFlow<Int> = _selectedFestivalYear.asStateFlow()

    private val _festivalCategoryFilter = MutableStateFlow<FestivalCategory?>(null)
    val festivalCategoryFilter: StateFlow<FestivalCategory?> = _festivalCategoryFilter.asStateFlow()

    private val _festivalSearchQuery = MutableStateFlow("")
    val festivalSearchQuery: StateFlow<String> = _festivalSearchQuery.asStateFlow()

    private val _todoFilter = MutableStateFlow(TodoFilter.ALL)
    val todoFilter: StateFlow<TodoFilter> = _todoFilter.asStateFlow()

    private val _eventTypeFilter = MutableStateFlow<String?>(null)
    val eventTypeFilter: StateFlow<String?> = _eventTypeFilter.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    val todosState: StateFlow<UiState<List<TodoItem>>> = repository.observeTodos(currentUserId)
        .map<List<TodoItem>, UiState<List<TodoItem>>> { list ->
            UiState.Success(
                list.sortedWith(compareBy<TodoItem> { it.completed }.thenBy { it.dateKey })
            )
        }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing todos", rootError)
            emit(UiState.Error(rootError.message ?: "टू-डू लोड करने में समस्या आई।"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val eventsState: StateFlow<UiState<List<PersonalEvent>>> = repository.observeEvents(currentUserId)
        .map<List<PersonalEvent>, UiState<List<PersonalEvent>>> { list ->
            UiState.Success(list.sortedBy { it.dateKey })
        }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing personal events", rootError)
            emit(UiState.Error(rootError.message ?: "इवेंट्स लोड करने में समस्या आई।"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    fun selectDate(date: CalendarDate) {
        _selectedDate.value = date
        _displayedYear.value = date.year
        _displayedMonth.value = date.month
    }

    fun jumpToToday() {
        val t = CalendarDate.today()
        _selectedDate.value = t
        _displayedYear.value = t.year
        _displayedMonth.value = t.month
    }

    fun previousMonth() {
        val m = _displayedMonth.value
        if (m == 1) {
            _displayedMonth.value = 12
            _displayedYear.value -= 1
        } else {
            _displayedMonth.value = m - 1
        }
    }

    fun nextMonth() {
        val m = _displayedMonth.value
        if (m == 12) {
            _displayedMonth.value = 1
            _displayedYear.value += 1
        } else {
            _displayedMonth.value = m + 1
        }
    }

    fun jumpToYearMonth(year: Int, month: Int) {
        val clampedMonth = month.coerceIn(1, 12)
        _displayedYear.value = year
        _displayedMonth.value = clampedMonth
        val maxDay = CalendarDate.daysInMonth(year, clampedMonth)
        val newDay = _selectedDate.value.day.coerceAtMost(maxDay)
        _selectedDate.value = CalendarDate(year, clampedMonth, newDay)
    }

    fun setFestivalYear(year: Int) {
        _selectedFestivalYear.value = year.coerceIn(
            IndianFestivalsCatalog.MIN_YEAR,
            IndianFestivalsCatalog.MAX_YEAR
        )
    }

    fun setFestivalCategory(category: FestivalCategory?) {
        _festivalCategoryFilter.value = category
    }

    fun setFestivalSearchQuery(query: String) {
        _festivalSearchQuery.value = query
    }

    fun setTodoFilter(filter: TodoFilter) {
        _todoFilter.value = filter
    }

    fun setEventTypeFilter(type: String?) {
        _eventTypeFilter.value = type
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    fun getUpcomingFestival(fromDate: CalendarDate = CalendarDate.today()): IndianFestival? {
        val fromKey = fromDate.toDateKey()
        return IndianFestivalsCatalog.allFestivals.firstOrNull { it.dateKey >= fromKey }
    }

    fun saveTodo(
        existingTodo: TodoItem?,
        title: String,
        notes: String,
        dateKey: String,
        priority: String,
        category: String
    ) {
        viewModelScope.launch {
            val result = if (existingTodo == null) {
                repository.createTodo(
                    TodoItem(
                        title = title,
                        notes = notes,
                        dateKey = dateKey,
                        priority = priority,
                        category = category,
                        completed = false
                    )
                ).map { }
            } else {
                repository.updateTodo(
                    existingTodo.copy(
                        title = title,
                        notes = notes,
                        dateKey = dateKey,
                        priority = priority,
                        category = category
                    )
                )
            }
            _snackbarMessage.value = if (result.isSuccess) {
                if (existingTodo == null) "टू-डू सफलतापूर्वक जोड़ा गया!" else "टू-डू अपडेट किया गया!"
            } else {
                "टू-डू सेव नहीं हो सका: ${result.exceptionOrNull()?.localizedMessage ?: "त्रुटि"}"
            }
        }
    }

    fun toggleTodoCompleted(todo: TodoItem) {
        viewModelScope.launch {
            val result = repository.toggleTodoCompleted(todo.id, !todo.completed)
            if (result.isFailure) {
                _snackbarMessage.value = "स्थिति अपडेट करने में त्रुटि हुई।"
            }
        }
    }

    fun deleteTodo(todoId: String) {
        viewModelScope.launch {
            val result = repository.deleteTodo(todoId)
            _snackbarMessage.value = if (result.isSuccess) {
                "टू-डू हटाया गया।"
            } else {
                "टू-डू हटाने में त्रुटि हुई।"
            }
        }
    }

    fun savePersonalEvent(
        existingEvent: PersonalEvent?,
        title: String,
        eventType: String,
        dateKey: String,
        repeatYearly: Boolean,
        timeLabel: String,
        location: String,
        notes: String
    ) {
        viewModelScope.launch {
            val result = if (existingEvent == null) {
                repository.createEvent(
                    PersonalEvent(
                        title = title,
                        eventType = eventType,
                        dateKey = dateKey,
                        repeatYearly = repeatYearly,
                        timeLabel = timeLabel,
                        location = location,
                        notes = notes
                    )
                ).map { }
            } else {
                repository.updateEvent(
                    existingEvent.copy(
                        title = title,
                        eventType = eventType,
                        dateKey = dateKey,
                        repeatYearly = repeatYearly,
                        timeLabel = timeLabel,
                        location = location,
                        notes = notes
                    )
                )
            }
            _snackbarMessage.value = if (result.isSuccess) {
                if (existingEvent == null) "अवसर कैलेंडर में जोड़ा गया!" else "अवसर अपडेट किया गया!"
            } else {
                "सेव करने में त्रुटि: ${result.exceptionOrNull()?.localizedMessage ?: "त्रुटि"}"
            }
        }
    }

    fun deletePersonalEvent(eventId: String) {
        viewModelScope.launch {
            val result = repository.deleteEvent(eventId)
            _snackbarMessage.value = if (result.isSuccess) {
                "अवसर हटाया गया।"
            } else {
                "हटाने में त्रुटि हुई।"
            }
        }
    }

    private companion object {
        const val TAG = "CalendarVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
