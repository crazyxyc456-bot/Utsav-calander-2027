package com.example.data.festivals

import com.example.data.model.IndianFestival
import com.example.util.CalendarDate

object IndianFestivalsCatalog {

    const val MIN_YEAR = 2000
    const val MAX_YEAR = 2035
    val SUPPORTED_YEARS: List<Int> = (MIN_YEAR..MAX_YEAR).toList()

    private fun buildFestival(dateKey: String, templateKey: String): IndianFestival? {
        val tpl = FestivalTemplates.all[templateKey] ?: return null
        return IndianFestival(
            id = "${templateKey}_${dateKey}",
            nameHi = tpl.nameHi,
            nameEn = tpl.nameEn,
            dateKey = dateKey,
            category = tpl.category,
            region = tpl.region,
            lunarTithi = tpl.lunarTithi,
            shortSummaryHi = tpl.shortSummaryHi,
            significanceHi = tpl.significanceHi,
            traditionsHi = tpl.traditionsHi,
            isGazettedHoliday = tpl.isGazettedHoliday
        )
    }

    private fun add(list: MutableList<IndianFestival>, dateKey: String, templateKey: String) {
        buildFestival(dateKey, templateKey)?.let { list.add(it) }
    }

    private fun expandYear(s: YearSchedule): List<IndianFestival> {
        val list = mutableListOf<IndianFestival>()
        val y = s.year
        val sankrantiStr = "$y-01-${s.sankrantiDay.toString().padStart(2, '0')}"
        val baisakhiStr = "$y-04-${s.baisakhiDay.toString().padStart(2, '0')}"

        // Fixed & Solar Festivals / National Events
        add(list, "$y-01-01", "new_year")
        add(list, "$y-01-13", "lohri")
        add(list, sankrantiStr, "makar_sankranti")
        add(list, sankrantiStr, "pongal")
        add(list, sankrantiStr, "bihu")
        add(list, "$y-01-23", "parakram_diwas")
        add(list, "$y-01-26", "republic_day")
        add(list, baisakhiStr, "baisakhi")
        add(list, "$y-04-14", "ambedkar_jayanti")
        add(list, "$y-${s.navroz}", "parsi_new_year")
        add(list, "$y-08-15", "independence_day")
        add(list, "$y-09-05", "teachers_day")
        add(list, "$y-09-17", "vishwakarma_puja")
        add(list, "$y-10-02", "gandhi_jayanti")
        add(list, "$y-11-14", "childrens_day")
        add(list, "$y-12-25", "christmas")
        add(list, "$y-12-31", "new_years_eve")

        // Hindu, Jain, Buddhist & Sikh Lunar Festivals
        add(list, "$y-${s.vasantPanchami}", "vasant_panchami")
        add(list, "$y-${s.mahaShivaratri}", "maha_shivaratri")

        val holiDate = CalendarDate.parse("$y-${s.holi}")
        if (holiDate != null) {
            add(list, holiDate.plusDays(-1).toDateKey(), "holika_dahan")
            add(list, holiDate.toDateKey(), "holi")
        }

        add(list, "$y-${s.gudiPadwa}", "gudi_padwa")
        add(list, "$y-${s.ramNavami}", "ram_navami")
        add(list, "$y-${s.mahavirJayanti}", "mahavir_jayanti")
        add(list, "$y-${s.hanumanJayanti}", "hanuman_jayanti")
        add(list, "$y-${s.akshayaTritiya}", "akshaya_tritiya")
        add(list, "$y-${s.buddhaPurnima}", "buddha_purnima")
        add(list, "$y-${s.rathYatra}", "rath_yatra")
        add(list, "$y-${s.guruPurnima}", "guru_purnima")
        add(list, "$y-${s.rakshaBandhan}", "raksha_bandhan")
        add(list, "$y-${s.janmashtami}", "janmashtami")
        add(list, "$y-${s.ganeshChaturthi}", "ganesh_chaturthi")
        add(list, "$y-${s.onam}", "onam")
        add(list, "$y-${s.navratriStart}", "navratri_start")
        add(list, "$y-${s.mahaAshtami}", "maha_ashtami")
        add(list, "$y-${s.dussehra}", "dussehra")
        add(list, "$y-${s.karwaChauth}", "karwa_chauth")
        add(list, "$y-${s.dhanteras}", "dhanteras")

        val diwaliDate = CalendarDate.parse("$y-${s.diwali}")
        if (diwaliDate != null) {
            add(list, diwaliDate.plusDays(-1).toDateKey(), "chhoti_diwali")
            add(list, diwaliDate.toDateKey(), "diwali")
            add(list, diwaliDate.plusDays(1).toDateKey(), "govardhan_puja")
            add(list, diwaliDate.plusDays(2).toDateKey(), "bhai_dooj")
        }

        add(list, "$y-${s.chhathPuja}", "chhath_puja")
        add(list, "$y-${s.guruNanakJayanti}", "guru_nanak_jayanti")
        add(list, "$y-${s.guruNanakJayanti}", "kartik_purnima")

        // Christian Festivals
        val goodFridayDate = CalendarDate.parse("$y-${s.goodFriday}")
        if (goodFridayDate != null) {
            add(list, goodFridayDate.toDateKey(), "good_friday")
            add(list, goodFridayDate.plusDays(2).toDateKey(), "easter_sunday")
        }

        // Islamic Festivals (supports 0, 1, or 2 occurrences per Gregorian year)
        s.eidUlFitr.forEach { add(list, "$y-$it", "eid_ul_fitr") }
        s.eidUlAdha.forEach { add(list, "$y-$it", "eid_ul_adha") }
        s.muharram.forEach { add(list, "$y-$it", "muharram") }
        s.miladUnNabi.forEach { add(list, "$y-$it", "milad_un_nabi") }

        return list
    }

    val allFestivals: List<IndianFestival> by lazy {
        val combinedSchedules = FestivalSchedules2000To2017.years + FestivalSchedules2018To2035.years
        combinedSchedules
            .flatMap { expandYear(it) }
            .distinctBy { it.id }
            .sortedWith(compareBy<IndianFestival> { it.dateKey }.thenBy { it.nameEn })
    }

    fun festivalsForDate(dateKey: String): List<IndianFestival> =
        allFestivals.filter { it.dateKey == dateKey }

    fun festivalsForMonth(year: Int, month: Int): List<IndianFestival> {
        val prefix = "$year-${month.toString().padStart(2, '0')}-"
        return allFestivals.filter { it.dateKey.startsWith(prefix) }
    }
}
