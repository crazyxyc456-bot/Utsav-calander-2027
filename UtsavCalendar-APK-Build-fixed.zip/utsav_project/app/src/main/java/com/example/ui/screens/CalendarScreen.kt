package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AddTask
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.festivals.IndianFestivalsCatalog
import com.example.data.model.IndianFestival
import com.example.data.model.PersonalEvent
import com.example.data.model.TodoItem
import com.example.ui.components.FestivalCard
import com.example.ui.components.PersonalEventCard
import com.example.ui.components.TodoItemCard
import com.example.ui.theme.MarigoldGold
import com.example.util.CalendarDate

@Composable
fun CalendarScreen(
    displayedYear: Int,
    displayedMonth: Int,
    selectedDate: CalendarDate,
    todos: List<TodoItem>,
    events: List<PersonalEvent>,
    onPreviousMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onJumpToday: () -> Unit,
    onJumpToYearMonth: (Int, Int) -> Unit,
    onSelectDate: (CalendarDate) -> Unit,
    onOpenFestival: (IndianFestival) -> Unit,
    onAddTodoForDate: (String) -> Unit,
    onEditTodo: (TodoItem) -> Unit,
    onToggleTodo: (TodoItem) -> Unit,
    onDeleteTodo: (String) -> Unit,
    onAddEventForDate: (String) -> Unit,
    onEditEvent: (PersonalEvent) -> Unit,
    onDeleteEvent: (String) -> Unit
) {
    var showMonthYearPicker by remember { mutableStateOf(false) }
    val today = remember { CalendarDate.today() }
    val gridCells = remember(displayedYear, displayedMonth) {
        CalendarDate.buildMonthGrid(displayedYear, displayedMonth)
    }
    val monthFestivals = remember(displayedYear, displayedMonth) {
        IndianFestivalsCatalog.festivalsForMonth(displayedYear, displayedMonth)
    }
    val festivalDateSet = remember(monthFestivals) {
        monthFestivals.map { it.dateKey }.toSet()
    }
    val todoDateSet = remember(todos) {
        todos.filter { !it.completed }.map { it.dateKey }.toSet()
    }

    val selectedDateKey = selectedDate.toDateKey()
    val selectedMonthDay = selectedDate.toMonthDayKey()

    val selectedFestivals = remember(selectedDateKey) {
        IndianFestivalsCatalog.festivalsForDate(selectedDateKey)
    }
    val selectedEvents = remember(events, selectedDateKey, selectedMonthDay) {
        events.filter { ev ->
            ev.dateKey == selectedDateKey ||
                (ev.repeatYearly && ev.dateKey.length == 10 && ev.dateKey.substring(5) == selectedMonthDay)
        }
    }
    val selectedTodos = remember(todos, selectedDateKey) {
        todos.filter { it.dateKey == selectedDateKey }
    }

    if (showMonthYearPicker) {
        MonthYearJumpDialog(
            initialYear = displayedYear,
            initialMonth = displayedMonth,
            onConfirm = { y, m ->
                onJumpToYearMonth(y, m)
                showMonthYearPicker = false
            },
            onDismiss = { showMonthYearPicker = false }
        )
    }

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                // Month Calendar Card
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Month Header Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            IconButton(
                                onClick = onPreviousMonth,
                                modifier = Modifier.testTag("calendar_prev_month_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                                    contentDescription = "पिछला महीना"
                                )
                            }

                            Surface(
                                onClick = { showMonthYearPicker = true },
                                shape = RoundedCornerShape(14.dp),
                                color = Color.Transparent,
                                modifier = Modifier.testTag("calendar_month_year_picker_button")
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "${CalendarDate.HINDI_MONTHS[displayedMonth - 1]} $displayedYear",
                                            style = MaterialTheme.typography.headlineSmall,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Icon(
                                            imageVector = Icons.Filled.ArrowDropDown,
                                            contentDescription = "महीना और वर्ष चुनें",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Text(
                                        text = CalendarDate.ENGLISH_MONTHS[displayedMonth - 1],
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = onJumpToday,
                                    modifier = Modifier.testTag("calendar_today_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Today,
                                        contentDescription = "आज की तारीख",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                                IconButton(
                                    onClick = onNextMonth,
                                    modifier = Modifier.testTag("calendar_next_month_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                        contentDescription = "अगला महीना"
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Weekday Header
                        Row(modifier = Modifier.fillMaxWidth()) {
                            CalendarDate.HINDI_WEEKDAYS_SHORT.forEachIndexed { idx, dayName ->
                                Text(
                                    text = dayName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (idx == 0) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    },
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Calendar 7-column weeks
                        gridCells.chunked(7).forEach { week ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                week.forEach { cellDate ->
                                    if (cellDate == null) {
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .aspectRatio(1f)
                                        )
                                    } else {
                                        val cellKey = cellDate.toDateKey()
                                        val cellMonthDay = cellDate.toMonthDayKey()
                                        val hasFestival = festivalDateSet.contains(cellKey)
                                        val hasTodo = todoDateSet.contains(cellKey)
                                        val hasEvent = events.any { ev ->
                                            ev.dateKey == cellKey ||
                                                (ev.repeatYearly && ev.dateKey.length == 10 && ev.dateKey.substring(5) == cellMonthDay)
                                        }
                                        CalendarDayCell(
                                            date = cellDate,
                                            isToday = cellDate == today,
                                            isSelected = cellDate == selectedDate,
                                            hasFestival = hasFestival,
                                            hasTodo = hasTodo,
                                            hasEvent = hasEvent,
                                            onClick = { onSelectDate(cellDate) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Legend row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            LegendDot(color = MarigoldGold, label = "त्योहार")
                            LegendDot(color = MaterialTheme.colorScheme.tertiary, label = "बर्थडे / पार्टी")
                            LegendDot(color = MaterialTheme.colorScheme.secondary, label = "टू-डू")
                        }
                    }
                }
            }

            // Selected Date Header & Quick Add Actions
            item {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = selectedDate.formatHindiFull(),
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold
                        )
                        if (selectedDate == today) {
                            Text(
                                text = "आज का दिन",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            FilledTonalButton(
                                onClick = { onAddTodoForDate(selectedDateKey) },
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("calendar_add_todo_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AddTask,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("टू-डू जोड़ें", maxLines = 1)
                            }
                            OutlinedButton(
                                onClick = { onAddEventForDate(selectedDateKey) },
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("calendar_add_event_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Cake,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("बर्थडे / पार्टी", maxLines = 1)
                            }
                        }
                    }
                }
            }

            // Festivals on Selected Date
            if (selectedFestivals.isNotEmpty()) {
                item {
                    SectionTitle(title = "इस दिन के भारतीय त्योहार")
                }
                items(selectedFestivals, key = { it.id }) { festival ->
                    FestivalCard(
                        festival = festival,
                        onClick = { onOpenFestival(festival) }
                    )
                }
            }

            // Personal Events on Selected Date
            if (selectedEvents.isNotEmpty()) {
                item {
                    SectionTitle(title = "जन्मदिन, पार्टी व विशेष अवसर")
                }
                items(selectedEvents, key = { it.id }) { event ->
                    PersonalEventCard(
                        event = event,
                        onEdit = { onEditEvent(event) },
                        onDelete = { onDeleteEvent(event.id) }
                    )
                }
            }

            // To-Dos on Selected Date
            if (selectedTodos.isNotEmpty()) {
                item {
                    SectionTitle(title = "इस दिन के महत्वपूर्ण टू-डू")
                }
                items(selectedTodos, key = { it.id }) { todo ->
                    TodoItemCard(
                        todo = todo,
                        onToggleCompleted = { onToggleTodo(todo) },
                        onEdit = { onEditTodo(todo) },
                        onDelete = { onDeleteTodo(todo.id) }
                    )
                }
            }

            if (selectedFestivals.isEmpty() && selectedEvents.isEmpty() && selectedTodos.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Filled.EventAvailable,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "इस तारीख को कोई त्योहार या कार्य दर्ज नहीं है",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "ऊपर दिए बटन से महत्वपूर्ण टू-डू, जन्मदिन या पार्टी जोड़ें।",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun CalendarDayCell(
    date: CalendarDate,
    isToday: Boolean,
    isSelected: Boolean,
    hasFestival: Boolean,
    hasTodo: Boolean,
    hasEvent: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor = when {
        isSelected -> MaterialTheme.colorScheme.primary
        isToday -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
        else -> Color.Transparent
    }
    val textColor = when {
        isSelected -> MaterialTheme.colorScheme.onPrimary
        date.dayOfWeekSundayFirst() == 0 -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.onSurface
    }
    val border = if (isToday && !isSelected) {
        BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
    } else null

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = bgColor,
        border = border,
        modifier = modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = date.day.toString(),
                style = MaterialTheme.typography.labelLarge,
                color = textColor,
                fontWeight = if (isSelected || isToday || hasFestival) FontWeight.Bold else FontWeight.Medium
            )
            if (hasFestival || hasEvent || hasTodo) {
                Spacer(modifier = Modifier.height(2.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    if (hasFestival) {
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) MaterialTheme.colorScheme.onPrimary else MarigoldGold)
                        )
                    }
                    if (hasEvent) {
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.tertiary)
                        )
                    }
                    if (hasTodo) {
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.secondary)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 4.dp)
    )
}

@Composable
private fun MonthYearJumpDialog(
    initialYear: Int,
    initialMonth: Int,
    onConfirm: (Int, Int) -> Unit,
    onDismiss: () -> Unit
) {
    var pickedYear by remember { mutableIntStateOf(initialYear) }
    var pickedMonth by remember { mutableIntStateOf(initialMonth) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "महीना व वर्ष चुनें (2000 – 2035)",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.heightIn(max = 180.dp)
                ) {
                    items(IndianFestivalsCatalog.SUPPORTED_YEARS) { year ->
                        val selected = year == pickedYear
                        Surface(
                            onClick = { pickedYear = year },
                            shape = RoundedCornerShape(10.dp),
                            color = if (selected) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                            }
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.padding(vertical = 8.dp)
                            ) {
                                Text(
                                    text = "$year",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (selected) {
                                        MaterialTheme.colorScheme.onPrimary
                                    } else {
                                        MaterialTheme.colorScheme.onSurface
                                    },
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                HorizontalDivider()

                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.heightIn(max = 180.dp)
                ) {
                    items((1..12).toList()) { month ->
                        val selected = month == pickedMonth
                        Surface(
                            onClick = { pickedMonth = month },
                            shape = RoundedCornerShape(10.dp),
                            color = if (selected) {
                                MaterialTheme.colorScheme.secondary
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                            }
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp)
                            ) {
                                Text(
                                    text = CalendarDate.HINDI_MONTHS[month - 1],
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (selected) {
                                        MaterialTheme.colorScheme.onSecondary
                                    } else {
                                        MaterialTheme.colorScheme.onSurface
                                    },
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(pickedYear, pickedMonth) }) {
                Text("खोलें")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("रद्द करें")
            }
        }
    )
}
