package com.example.data.model

enum class FestivalCategory(val labelHi: String, val labelEn: String) {
    NATIONAL("राष्ट्रीय पर्व", "National"),
    HINDU("हिंदू पर्व", "Hindu"),
    HARVEST_REGIONAL("फसल व क्षेत्रीय", "Harvest & Regional"),
    ISLAMIC("इस्लामी पर्व", "Islamic"),
    SIKH("सिख पर्व", "Sikh"),
    CHRISTIAN("ईसाई पर्व", "Christian"),
    JAIN_BUDDHIST("जैन व बौद्ध", "Jain & Buddhist")
}

data class IndianFestival(
    val id: String,
    val nameHi: String,
    val nameEn: String,
    val dateKey: String,
    val category: FestivalCategory,
    val region: String,
    val lunarTithi: String,
    val shortSummaryHi: String,
    val significanceHi: String,
    val traditionsHi: List<String>,
    val isGazettedHoliday: Boolean = false
)
