package com.example.util

import java.util.Calendar
import java.util.GregorianCalendar

data class CalendarDate(
    val year: Int,
    val month: Int, // 1..12
    val day: Int    // 1..31
) : Comparable<CalendarDate> {

    fun toDateKey(): String {
        val m = month.toString().padStart(2, '0')
        val d = day.toString().padStart(2, '0')
        return "$year-$m-$d"
    }

    fun toMonthDayKey(): String {
        val m = month.toString().padStart(2, '0')
        val d = day.toString().padStart(2, '0')
        return "$m-$d"
    }

    fun dayOfWeekSundayFirst(): Int {
        val cal = GregorianCalendar(year, month - 1, day)
        return cal.get(Calendar.DAY_OF_WEEK) - 1 // 0 = Sun .. 6 = Sat
    }

    fun plusDays(days: Int): CalendarDate {
        val cal = GregorianCalendar(year, month - 1, day)
        cal.add(Calendar.DAY_OF_MONTH, days)
        return CalendarDate(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    fun formatHindiFull(): String {
        val weekday = HINDI_WEEKDAYS_FULL[dayOfWeekSundayFirst()]
        val monthName = HINDI_MONTHS[month - 1]
        return "$weekday, $day $monthName $year"
    }

    fun formatShort(): String {
        val monthShort = HINDI_MONTHS_SHORT[month - 1]
        return "$day $monthShort $year"
    }

    override fun compareTo(other: CalendarDate): Int {
        return compareValuesBy(this, other, { it.year }, { it.month }, { it.day })
    }

    companion object {
        val HINDI_MONTHS = listOf(
            "जनवरी", "फ़रवरी", "मार्च", "अप्रैल", "मई", "जून",
            "जुलाई", "अगस्त", "सितंबर", "अक्टूबर", "नवंबर", "दिसंबर"
        )

        val HINDI_MONTHS_SHORT = listOf(
            "जन", "फ़र", "मार्च", "अप्रै", "मई", "जून",
            "जुल", "अग", "सित", "अक्टू", "नव", "दिस"
        )

        val ENGLISH_MONTHS = listOf(
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        )

        val HINDI_WEEKDAYS_SHORT = listOf("रवि", "सोम", "मंगल", "बुध", "गुरु", "शुक्र", "शनि")
        val HINDI_WEEKDAYS_FULL = listOf(
            "रविवार", "सोमवार", "मंगलवार", "बुधवार", "गुरुवार", "शुक्रवार", "शनिवार"
        )

        fun today(): CalendarDate {
            val cal = Calendar.getInstance()
            return CalendarDate(
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH) + 1,
                cal.get(Calendar.DAY_OF_MONTH)
            )
        }

        fun daysInMonth(year: Int, month: Int): Int {
            val cal = GregorianCalendar(year, month - 1, 1)
            return cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        }

        fun parse(dateKey: String): CalendarDate? {
            val parts = dateKey.split("-")
            if (parts.size != 3) return null
            val y = parts[0].toIntOrNull() ?: return null
            val m = parts[1].toIntOrNull() ?: return null
            val d = parts[2].toIntOrNull() ?: return null
            if (m !in 1..12) return null
            val maxD = daysInMonth(y, m)
            if (d !in 1..maxD) return null
            return CalendarDate(y, m, d)
        }

        fun isValidDateKey(dateKey: String): Boolean = parse(dateKey) != null

        fun buildMonthGrid(year: Int, month: Int): List<CalendarDate?> {
            val firstDayOffset = CalendarDate(year, month, 1).dayOfWeekSundayFirst()
            val totalDays = daysInMonth(year, month)
            val cells = mutableListOf<CalendarDate?>()
            repeat(firstDayOffset) { cells.add(null) }
            for (d in 1..totalDays) {
                cells.add(CalendarDate(year, month, d))
            }
            while (cells.size % 7 != 0) {
                cells.add(null)
            }
            return cells
        }
    }
}
