package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = SaffronPrimary,
    onPrimary = SaffronOnPrimary,
    primaryContainer = SaffronPrimaryContainer,
    onPrimaryContainer = SaffronOnPrimaryContainer,
    secondary = EmeraldSecondary,
    onSecondary = EmeraldOnSecondary,
    secondaryContainer = EmeraldSecondaryContainer,
    onSecondaryContainer = EmeraldOnSecondaryContainer,
    tertiary = KumkumTertiary,
    onTertiary = KumkumOnTertiary,
    tertiaryContainer = KumkumTertiaryContainer,
    onTertiaryContainer = KumkumOnTertiaryContainer,
    background = IvoryBackground,
    onBackground = WarmOnSurface,
    surface = IvorySurface,
    onSurface = WarmOnSurface,
    surfaceVariant = IvorySurfaceVariant,
    onSurfaceVariant = WarmOnSurfaceVariant,
    outline = WarmOutline,
    outlineVariant = WarmOutlineVariant
)

private val DarkColorScheme = darkColorScheme(
    primary = DarkSaffronPrimary,
    onPrimary = DarkSaffronOnPrimary,
    primaryContainer = DarkSaffronPrimaryContainer,
    onPrimaryContainer = DarkSaffronOnPrimaryContainer,
    secondary = DarkEmeraldSecondary,
    onSecondary = DarkEmeraldOnSecondary,
    secondaryContainer = DarkEmeraldSecondaryContainer,
    onSecondaryContainer = DarkEmeraldOnSecondaryContainer,
    tertiary = DarkKumkumTertiary,
    onTertiary = DarkKumkumOnTertiary,
    tertiaryContainer = DarkKumkumTertiaryContainer,
    onTertiaryContainer = DarkKumkumOnTertiaryContainer,
    background = DarkBackground,
    onBackground = DarkOnSurface,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceVariant,
    outline = DarkOutline,
    outlineVariant = DarkOutlineVariant
)

val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun UtsavCalendarTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = AppShapes,
        content = content
    )
}
