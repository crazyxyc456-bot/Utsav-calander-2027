package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm Ivory & Marigold Saffron Palette
val SaffronPrimary = Color(0xFFC84B11)
val SaffronOnPrimary = Color(0xFFFFFFFF)
val SaffronPrimaryContainer = Color(0xFFFFDFCE)
val SaffronOnPrimaryContainer = Color(0xFF421200)

val EmeraldSecondary = Color(0xFF0F6E5D)
val EmeraldOnSecondary = Color(0xFFFFFFFF)
val EmeraldSecondaryContainer = Color(0xFFC5F2E6)
val EmeraldOnSecondaryContainer = Color(0xFF00241D)

val KumkumTertiary = Color(0xFFA62653)
val KumkumOnTertiary = Color(0xFFFFFFFF)
val KumkumTertiaryContainer = Color(0xFFFFD9E2)
val KumkumOnTertiaryContainer = Color(0xFF3E001A)

val MarigoldGold = Color(0xFFD99116)
val MarigoldGoldSoft = Color(0xFFFFF0CA)

val IvoryBackground = Color(0xFFFFFDF8)
val IvorySurface = Color(0xFFFFFAF2)
val IvorySurfaceVariant = Color(0xFFF6E9D8)
val WarmOnSurface = Color(0xFF241914)
val WarmOnSurfaceVariant = Color(0xFF5D4B41)
val WarmOutline = Color(0xFF8C776B)
val WarmOutlineVariant = Color(0xFFE3D3C3)

// Dark Theme Tokens
val DarkSaffronPrimary = Color(0xFFFFB596)
val DarkSaffronOnPrimary = Color(0xFF5D1D00)
val DarkSaffronPrimaryContainer = Color(0xFF8C3103)
val DarkSaffronOnPrimaryContainer = Color(0xFFFFDFCE)

val DarkEmeraldSecondary = Color(0xFF7AD8C4)
val DarkEmeraldOnSecondary = Color(0xFF00382E)
val DarkEmeraldSecondaryContainer = Color(0xFF005144)
val DarkEmeraldOnSecondaryContainer = Color(0xFFC5F2E6)

val DarkKumkumTertiary = Color(0xFFFFB1C7)
val DarkKumkumOnTertiary = Color(0xFF65002D)
val DarkKumkumTertiaryContainer = Color(0xFF860D3D)
val DarkKumkumOnTertiaryContainer = Color(0xFFFFD9E2)

val DarkBackground = Color(0xFF19120F)
val DarkSurface = Color(0xFF211915)
val DarkSurfaceVariant = Color(0xFF362A24)
val DarkOnSurface = Color(0xFFF5E9E0)
val DarkOnSurfaceVariant = Color(0xFFD5C2B6)
val DarkOutline = Color(0xFF9E8A7E)
val DarkOutlineVariant = Color(0xFF4F3E35)
