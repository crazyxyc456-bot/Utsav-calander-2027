package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.PersonalEvent
import com.example.data.model.TodoItem
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CalendarRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun createAndObserveTodo_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repo = CalendarRepository(firestore, auth)

        val todoId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createTodo(
                TodoItem(
                    title = "दीपावली के लिए मिठाई और दीये लाना",
                    notes = "घी के दीये और रंगोली रंग",
                    dateKey = "2026-11-08",
                    priority = "high",
                    category = "festival_prep",
                    completed = false
                )
            ).getOrThrow()
        }
        assertTrue(todoId.isNotBlank())

        val todos = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeTodos(uid).first { list -> list.any { it.id == todoId } }
        }
        val created = todos.first { it.id == todoId }
        assertEquals("दीपावली के लिए मिठाई और दीये लाना", created.title)
        assertFalse(created.completed)

        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.toggleTodoCompleted(todoId, true).getOrThrow()
        }
        val updated = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeTodos(uid).first { list -> list.any { it.id == todoId && it.completed } }
        }
        assertTrue(updated.first { it.id == todoId }.completed)
    }

    @Test
    fun createAndUpdatePersonalEvent_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repo = CalendarRepository(firestore, auth)

        val eventId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createEvent(
                PersonalEvent(
                    title = "आरव की बर्थडे पार्टी",
                    eventType = "birthday",
                    dateKey = "2026-11-20",
                    repeatYearly = true,
                    timeLabel = "07:30 PM",
                    location = "घर की छत",
                    notes = "केक और गुब्बारे"
                )
            ).getOrThrow()
        }
        assertTrue(eventId.isNotBlank())

        val events = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeEvents(uid).first { list -> list.any { it.id == eventId } }
        }
        assertEquals("आरव की बर्थडे पार्टी", events.first { it.id == eventId }.title)

        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.deleteEvent(eventId).getOrThrow()
        }
    }

    @Test
    fun crossUserAccess_deniedWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = CalendarRepository(firestore, auth)
        val todoId = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.createTodo(
                TodoItem(
                    title = "Alice Private Task",
                    dateKey = "2026-11-15",
                    priority = "medium",
                    category = "personal"
                )
            ).getOrThrow()
        }

        signInTestUser(BOB_EMAIL)
        val bobRepo = CalendarRepository(firestore, auth)
        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.getTodoById(aliceUid, todoId)
        }
        assertTrue(result.isFailure)
        val fsEx = result.exceptionOrNull()?.unwrapFirestoreException()
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
    }

    @Test
    fun unauthenticatedObserve_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repo = CalendarRepository(firestore, auth)

        var caught: Throwable? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repo.observeTodos("some_uid_123").first()
            }
        } catch (t: Throwable) {
            caught = t
        }
        val fsEx = caught?.unwrapFirestoreException()
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
    }

    private companion object {
        const val ALICE_EMAIL = "alice_utsav@test.com"
        const val BOB_EMAIL = "bob_utsav@test.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
