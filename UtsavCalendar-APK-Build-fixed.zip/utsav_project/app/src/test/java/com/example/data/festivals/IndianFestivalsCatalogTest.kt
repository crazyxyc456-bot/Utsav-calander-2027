package com.example.data.festivals

import com.example.data.model.FestivalCategory
import com.example.util.CalendarDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class IndianFestivalsCatalogTest {

    @Test
    fun `every year from 2000 to 2035 has valid complete festival and event entries`() {
        val all = IndianFestivalsCatalog.allFestivals
        assertTrue("Expected >1600 festivals across 2000..2035", all.size >= 1600)

        // Ensure unique IDs
        assertEquals(all.size, all.map { it.id }.distinct().size)

        // Ensure every single dateKey is valid and all required info is populated
        all.forEach { fest ->
            assertTrue("Invalid dateKey: ${fest.dateKey} for ${fest.id}", CalendarDate.isValidDateKey(fest.dateKey))
            assertTrue(fest.nameHi.isNotBlank())
            assertTrue(fest.nameEn.isNotBlank())
            assertTrue(fest.region.isNotBlank())
            assertTrue(fest.lunarTithi.isNotBlank())
            assertTrue(fest.shortSummaryHi.isNotBlank())
            assertTrue(fest.significanceHi.isNotBlank())
            assertTrue(fest.traditionsHi.isNotEmpty())
        }

        // Verify coverage for every single year from 2000 through 2035
        for (year in 2000..2035) {
            val yearList = all.filter { it.dateKey.startsWith("$year-") }
            assertTrue("Year $year should have >= 45 festivals/events, got ${yearList.size}", yearList.size >= 45)
            val categories = yearList.map { it.category }.toSet()
            assertEquals("Year $year should cover all 7 categories", FestivalCategory.entries.toSet(), categories)
        }
    }

    @Test
    fun `milestone festival dates across 2000 to 2035 match catalog`() {
        assertTrue(IndianFestivalsCatalog.festivalsForDate("2000-10-26").any { it.nameEn == "Diwali" })
        assertTrue(IndianFestivalsCatalog.festivalsForDate("2026-11-08").any { it.nameEn == "Diwali" })
        assertTrue(IndianFestivalsCatalog.festivalsForDate("2035-10-30").any { it.nameEn == "Diwali" })
        assertTrue(IndianFestivalsCatalog.festivalsForDate("2035-03-24").any { it.nameEn == "Holi" })
        assertTrue(IndianFestivalsCatalog.festivalsForDate("2033-12-23").any { it.nameEn == "Eid-ul-Fitr" })
        assertTrue(IndianFestivalsCatalog.festivalsForDate("2000-01-01").any { it.nameEn == "New Year's Day" })
        assertTrue(IndianFestivalsCatalog.festivalsForDate("2035-12-31").any { it.nameEn == "New Year's Eve" })
    }
}
