const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function validTodoPayload(uid, overrides = {}) {
  const past = new Date(Date.now() - 5000);
  return {
    userId: uid,
    title: "Buy Diwali diyas and rangoli colors",
    notes: "Visit Chandni Chowk market",
    dateKey: "2026-11-08",
    priority: "high",
    category: "festival_prep",
    completed: false,
    createdAt: past,
    updatedAt: past,
    ...overrides,
  };
}

function validEventPayload(uid, overrides = {}) {
  const past = new Date(Date.now() - 5000);
  return {
    userId: uid,
    title: "Aarav's Birthday Party",
    eventType: "birthday",
    dateKey: "2026-11-20",
    repeatYearly: true,
    timeLabel: "07:30 PM",
    location: "Home Terrace",
    notes: "Order mango cake",
    createdAt: past,
    updatedAt: past,
    ...overrides,
  };
}

// --- SECURITY BOUNDS: TODOS ---

test("Unauthenticated user cannot read or write todos", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection(`users/${ALICE_UID}/todos`).get());
  await assertFails(
    unauthDb
      .collection(`users/${ALICE_UID}/todos`)
      .doc("todo_1")
      .set(validTodoPayload(ALICE_UID))
  );
});

test("Authenticated owner can create, list, update, and delete own todo", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const docRef = aliceDb.collection(`users/${ALICE_UID}/todos`).doc("todo_1");

  await assertSucceeds(docRef.set(validTodoPayload(ALICE_UID)));
  await assertSucceeds(aliceDb.collection(`users/${ALICE_UID}/todos`).get());
  await assertSucceeds(
    docRef.update({
      completed: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertSucceeds(docRef.delete());
});

test("Cross-user access to todos is denied", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context
      .firestore()
      .collection(`users/${ALICE_UID}/todos`)
      .doc("alice_todo")
      .set(validTodoPayload(ALICE_UID));
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection(`users/${ALICE_UID}/todos`).get());
  await assertFails(
    bobDb.collection(`users/${ALICE_UID}/todos`).doc("alice_todo").get()
  );
  await assertFails(
    bobDb
      .collection(`users/${ALICE_UID}/todos`)
      .doc("bob_inject")
      .set(validTodoPayload(BOB_UID))
  );
});

test("Shadow update with ghost field or immutable field change on todo is denied", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const docRef = aliceDb.collection(`users/${ALICE_UID}/todos`).doc("todo_shadow");

  // Ghost field on create
  await assertFails(
    docRef.set(validTodoPayload(ALICE_UID, { isVerified: true }))
  );

  // Valid create
  await assertSucceeds(docRef.set(validTodoPayload(ALICE_UID)));

  // Ghost field on update
  await assertFails(
    docRef.update({
      title: "Updated",
      ghostField: "hack",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Changing immutable createdAt
  await assertFails(
    docRef.update({
      createdAt: new Date(Date.now() - 100),
      updatedAt: new Date(Date.now() - 1000),
    })
  );
});

test("Invalid todo payload (bad dateKey, empty title, bad priority) is denied", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb
      .collection(`users/${ALICE_UID}/todos`)
      .doc("bad_date")
      .set(validTodoPayload(ALICE_UID, { dateKey: "14-11-2026" }))
  );
  await assertFails(
    aliceDb
      .collection(`users/${ALICE_UID}/todos`)
      .doc("empty_title")
      .set(validTodoPayload(ALICE_UID, { title: "" }))
  );
  await assertFails(
    aliceDb
      .collection(`users/${ALICE_UID}/todos`)
      .doc("bad_priority")
      .set(validTodoPayload(ALICE_UID, { priority: "urgent" }))
  );
});

// --- SECURITY BOUNDS: PERSONAL EVENTS ---

test("Unauthenticated user cannot read or write personal events", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection(`users/${ALICE_UID}/events`).get());
  await assertFails(
    unauthDb
      .collection(`users/${ALICE_UID}/events`)
      .doc("ev_1")
      .set(validEventPayload(ALICE_UID))
  );
});

test("Authenticated owner can create, list, update, and delete personal event", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const docRef = aliceDb.collection(`users/${ALICE_UID}/events`).doc("ev_1");

  await assertSucceeds(docRef.set(validEventPayload(ALICE_UID)));
  await assertSucceeds(aliceDb.collection(`users/${ALICE_UID}/events`).get());
  await assertSucceeds(
    docRef.update({
      location: "Rooftop Garden",
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertSucceeds(docRef.delete());
});

test("Cross-user access to personal events is denied", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context
      .firestore()
      .collection(`users/${ALICE_UID}/events`)
      .doc("alice_ev")
      .set(validEventPayload(ALICE_UID));
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection(`users/${ALICE_UID}/events`).get());
  await assertFails(
    bobDb.collection(`users/${ALICE_UID}/events`).doc("alice_ev").get()
  );
});

test("Invalid personal event payload (invalid eventType or ghost field) is denied", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb
      .collection(`users/${ALICE_UID}/events`)
      .doc("bad_type")
      .set(validEventPayload(ALICE_UID, { eventType: "invalid_type" }))
  );
  await assertFails(
    aliceDb
      .collection(`users/${ALICE_UID}/events`)
      .doc("ghost")
      .set(validEventPayload(ALICE_UID, { admin: true }))
  );
});
